import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
import java.util.Vector;

/**
 * 
 */

/**
 * @author A
 *
 */
public class gigaIndex {

    /*  This is a class that has a nameIndex, and has a coordinate index. For some reason. So, this will take in a file or a GIS record,
     * and then index everything by NAME, and then also index everything by COORDINATE. the NAME is going into a hashtable. the COORDINATE is
     * going into a prQuadTree
     */
    private nameIndexer name;
    private prQuadTree<coordinate> prquad;
    public long xMin;
    public long yMin;
    public long xMax;
    public long yMax;
    
    public gigaIndex() {
        // bounds of the world?
        // here we take in world boundaries probably
        name = new nameIndexer();
        prquad = null;
        
    }
    
    /* Pay attention/careful about the order!*/
    public void quadMaker(long westMin, long northMin, long westMax, long northMax) {
        this.prquad = new prQuadTree<coordinate>(westMin, northMin, westMax, northMax);
        this.xMin = westMin;
        this.yMin = northMin;
        this.xMax = westMax;
        this.yMax = northMax;
        
    }
    
    
    
    public void insertName(String gisrecord) throws IOException {
        name.megaInsert(gisrecord);
        //name.theTable().displayx();
        
        /** Maybe this should:
         * 
         * Read a GIS file
         * Take in all of the values for each record
         * create a nameEntry object for each record, adding it into the name index
         * create a coordinate object for each record, adding it to the pr tree
         * 
         */
    }
    
    
    /* This is the main meat of the program, it handles all indexing and inserts each record
     * into nameEntry indexes and coordinate indexes. Note that these are 2 separate objects
     * 
     * @param filename    Filename 
     * @param Offset        The last offset in our database file
     */
    public int[] fullIndexTry(String filename, long lastOffset) {
        int nimport = 0;
        int limport = 0;
        int[] importnums = new int[2];
        try {
            /* Counters for name and location indexes*/
            
            File gis = new File(filename);
            RandomAccessFile r = new RandomAccessFile(gis, "r");

            // start:
            Scanner readfull = new Scanner(gis);
            // check the first line and get scanner and file to their starting positions
          

                            /* new line: this goes to the last offset. this is in the case where ther are 2, 10, or 824 new imports. we don't want to
                             * recreate the table and quadtree each time, so we just store the long pointer and index everything new. idk if this is right.
                             * 
                             * To make this work, we actually keep the "FEATURE NAME|FEATURE ID|STATE ALPHA" etc part of each record. We add the entire gis file every time,
                             * so that it runs right on the first import as well as import # 92381
                             */
            
                                            r.seek(lastOffset);
                                            readfull.nextLine();
                                            r.readLine();
            
             // while scanner has next line, add those entries?
                                            System.out.println(" about to ender readfull loop in gigaindex fulindextry");
            while (readfull.hasNextLine()) {
                Long offie = r.getFilePointer();
                String readline = r.readLine();
                
                if (readline == null) {
                    break;
                }
                Scanner scanner = new Scanner(readline);
                scanner.useDelimiter("\\|");

                // get past feature id:
                scanner.next();                         /* Feature ID*/
                String featurename = scanner.next();    /* Feature name*/
                scanner.next();                         /* Feature class*/
                String featurestate = scanner.next();   /* Feature State*/
                scanner.next();                         /* State numeric*/
                scanner.next();                         /* County name*/
                scanner.next();                         /* County numeric*/
                String primLatN = scanner.next();
                String primLongW = scanner.next();
                primLatN = primLatN.substring(0, primLatN.length() - 1);
                primLongW = primLongW.substring(0, primLongW.length() - 1);
                
                                /* Logic to create a coordinate and put it into the tree*/
                        
                        /* This is hindered in NM_All because of the case where they lack long/lat data. So:*/
                        /* This seems so messy and like an unnecessary check to m,e but it seems necessary!*/
                if (primLatN.contains("Unknow") || primLongW.contains("Unknow")) {
                    
                }
                else {
                        coordinate coordinate = new coordinate(Long.parseLong(primLatN), Long.parseLong(primLongW), offie);
                        //System.out.println("Inserting coordinate!!!! wow " + coordinate.toString() + "Or.. " + coordinate.getX() + "  and " + coordinate.getY());
                        prquad.insert(coordinate);
                        limport++;
                         
                }
                
                
                
                            /* Create a nameEntry and put it in nameIndex*/
                    String fullname = featurename + featurestate;
                    //Long offie = r.getFilePointer();
                    nameEntry n = new nameEntry(fullname, offie);
                   // name.hash.displayx();
                    
                    /* null checks aren't needed here */
                    name.newInsert(n);
                    nimport++;
                    
                    if (fullname.contains("Eagle PeakNM")) {
                        System.out.println(" I'm inserting Eagle peak NM!!!! I am gigaindex");
                    }
                    //name.hash.displayx();
                // close scanner?
                scanner.close(); //************************************************
                
                                                                                /* Our almighty system outprint, to fix the last problem:*/
                           // System.out.println("I just indexed : " + featurename + " " + primLatN + " " + primLongW);

            }
            
            /* assign to int array*/
            importnums[0] = nimport;
            importnums[1] = limport;
            // close all of them:
            
            readfull.close();
            r.close();

            return importnums;
            //System.out.println(" NEW INSERT METHOD CALLED. here's the tree: ");
           // prquad.printTreeHelper(prquad.root, "   " );
            //hash.printAll();
            //System.out.println("the table at 256 like this: ");
            //hash.display();
            //System.out.println("new table, resized, like this : ");
            //hash.displayx();
        } catch (FileNotFoundException e) {
            System.out.println(" Error in indexing ");
            e.printStackTrace();
            System.exit(100);
        }
        catch (IOException e) {
            
            e.printStackTrace();
        }
        return null;
    }
    
    
    
    
    /* getter for nameINdeX*/
    public nameIndexer getNameIndex() {
        return this.name;
    }
    
    /* debug hash*/
    public void hashDebug(FileWriter o) {
        name.displayHashPrint(o);
    }
    
    public nameEntry nameLookUp(String together) {       
        //System.out.println(" in name lookup!");
        /* Note: instead of passing in null, I'll try assigning an arbitary offset and passing that in*/
        nameEntry l = new nameEntry(together, 0L);
       // System.out.println(" past nameEntry creation!");
        
        nameEntry fd = name.lookUp(l);
        
        if (fd != null) {
            return fd;
        }
        return null;
//        try {
//            return name.lookUp(l);
//        }
//        catch (Exception e) {
//            System.out.println(" excpetion.. hmmmmm. in the catcdh block of namelookup");
//            e.printStackTrace();
//        }
//        //nameEntry n = name.lookUp(new nameEntry(together, 0L));
////        if (n == null) {
////            System.out.println(" I'm in namelookup. n is null");
////        }
////        else {
////            System.out.println(n.key() + " < -- foudn this key!");
////            return n;
////        }
//        return null;
    }
    
    /* Range find method!*/
    public Vector<coordinate> findrange(long one, long two, long three, long four) {
        return prquad.find(one, two, three, four);
    }
    
    /* Simply writes to tree*/
    public void writeTree(FileWriter out) {
        prquad.printTreeHelper(out, prquad.rootget(), "  ", 4);
    }
    
    /* Retrieve prQuad*/
    public prQuadTree<coordinate> getprQuad() {
        return this.prquad;
    }

    /* Find our coordinate*/
    public coordinate findCoordinate(coordinate cr) {
        return (prquad.find(cr));
    }
    
    
    
    
}
