import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

/** This is our buffer pool - it uses ArrayList of Strings for the slots, simply calling add to add to the front.
 * @author  Josh Pandey
 *
 */
public class bufferPool {

    private ArrayList<String> buffer;
    private final int maxSize = 15;
    
    public bufferPool() {
        buffer = new ArrayList<String>(15);
    }
    
    
    public void addToBuffer(String str, long offset) {
        // add most recently used items to the front
        
        String offs = offset + "|";
        String total = offs + str;
        buffer.add(0, total);
        
        if (buffer.size() >= maxSize) {
            this.resize();
        }
    }
    
    public void resize() {
        // remove the last entry
        
        // can be just remove(14), but keep it like this:
        buffer.remove(buffer.size() - 1);
    }
    

    public String[] retrieverFull(String fl, long offset, int command) {
        /* open the db file */
        String[] arr = new String[5];
        
        // on every call, just check the buffer to see if this is there:
        for (String item : buffer) {
            Scanner scanoff = new Scanner(item);
            scanoff.useDelimiter("\\|");
                                if (Long.valueOf(scanoff.next()) == offset) {
                                    // offsets are the same, retrieve this record
                                    
                                    String featureName = scanoff.next(); /* Feature name*/
                                    scanoff.next(); /* Feature class*/
                                    String state = scanoff.next(); /* State alpha*/
                                    scanoff.next(); /* State numeric*/
                                    String countyName = scanoff.next(); /* County name*/
                                    scanoff.next(); /* County numeric*/
                                    String primLatN = scanoff.next();
                                    String primLongW = scanoff.next();
                                    
                                    String westDeg = primLongW.substring(0, 3);
                                    String westMin = primLongW.substring(3, 5);
                                    String westSec = primLongW.substring(5, 7);
                                    
                                    if (westDeg.charAt(0) == '0') {
                                        westDeg = westDeg.substring(1);
                                    }
                                    if (westMin.charAt(0) == '0') {
                                        westMin = westMin.substring(1);
                                    }
                                    if (westSec.charAt(0) == '0') {
                                        westSec = westSec.substring(1);
                                    }
                                    
                                    String totalWest = westDeg + "d " + westMin + "m "
                                        + westSec + "s West,";
                                    String totalNorth = primLatN.substring(0, 2) + "d " + primLatN.substring(2, 4) +"m "
                                        + primLatN.substring(4, 6) + "s North";
                                
                                
                                    
                                        /* Command logic: This follows so that in our main call,
                                         * we can always just print arr[1], arr[2], arr[3], etc.
                                         */
                                        /* better way is with ints*/
                                    
                                    /* What is case. I used an int instead of comparing strings :*/
                                    if (command == 1) {
                                        arr[0] = countyName;
                                        arr[1] = totalNorth;
                                        arr[2] = totalWest;
                                    }
                                    /* What is at case:*/
                                    if (command == 2) {
                                        arr[0] = featureName;
                                        arr[1] = countyName;
                                        arr[2] = state;
                                        arr[3] = totalWest; /* Used these to print onto logfile*/
                                        arr[4] = totalNorth; /* Used this to print onto logfile*/
                                    }
                                    
                                    if (command == 3) {
                                        arr[0] = featureName;
                                        arr[1] = state;
                                        arr[2] = primLatN;
                                        arr[3] = primLongW;
                                    }
                                
                                
                                return arr;
                                    
                                }
        }
        
        
        
        
        
        
        
                        /* Repeating the same logic as above. But now we access the disk. */
        
        
        
        try {
            RandomAccessFile raf = new RandomAccessFile(fl, "r");
            raf.seek(offset);
            String readline = raf.readLine();
            
            /* The following applies for any record, so we'll keep it as a general
             * rule:*/
             
                if (readline == null) {
                    return null;
                }
                
                /* if the buffer size is less than 15, add it :*/
                
                if (buffer.size() < 15) {
                    buffer.add(readline);
                }
                
                /* I wonder if this is inefficient, but then I remember
                 * it's called essentially a maximum of the number of
                 * commands there are in a file; so it's likely constant,
                 * since n would be GIs records? Sorry if this is messy, it's
                 * neatly organized/clean reasoning to me! There is a better way
                 * to do this, most likely, though. I wanted to avoid loops because
                 * if I were in any professional setting, I'd keep it like this
                 * for easy access to any changes
                 */
                //System.out.println(" readline is : " + readline);
                Scanner scanner = new Scanner(readline);
                scanner.useDelimiter("\\|");
                scanner.next(); /* Feature ID*/
                String featureName = scanner.next(); /* Feature name*/
                scanner.next(); /* Feature class*/
                String state = scanner.next(); /* State alpha*/
                scanner.next(); /* State numeric*/
                String countyName = scanner.next(); /* County name*/
                scanner.next(); /* County numeric*/
                String primLatN = scanner.next();
                String primLongW = scanner.next();
                
                String westDeg = primLongW.substring(0, 3);
                String westMin = primLongW.substring(3, 5);
                String westSec = primLongW.substring(5, 7);
                
                if (westDeg.charAt(0) == '0') {
                    westDeg = westDeg.substring(1);
                }
                if (westMin.charAt(0) == '0') {
                    westMin = westMin.substring(1);
                }
                if (westSec.charAt(0) == '0') {
                    westSec = westSec.substring(1);
                }
                
                String totalWest = westDeg + "d " + westMin + "m "
                    + westSec + "s West,";
                String totalNorth = primLatN.substring(0, 2) + "d " + primLatN.substring(2, 4) +"m "
                    + primLatN.substring(4, 6) + "s North";
            
            
                
                    /* Command logic: This follows so that in our main call,
                     * we can always just print arr[1], arr[2], arr[3], etc.
                     */
                    /* better way is with ints*/
                
                /* What is case. I used an int instead of comparing strings :*/
                if (command == 1) {
                    arr[0] = countyName;
                    arr[1] = totalNorth;
                    arr[2] = totalWest;
                }
                /* What is at case:*/
                if (command == 2) {
                    arr[0] = featureName;
                    arr[1] = countyName;
                    arr[2] = state;
                    arr[3] = totalWest; /* Used these to print onto logfile*/
                    arr[4] = totalNorth; /* Used this to print onto logfile*/
                }
                
                if (command == 3) {
                    arr[0] = featureName;
                    arr[1] = state;
                    arr[2] = primLatN;
                    arr[3] = primLongW;
                }
            
            
            return arr;
        }
        catch (Exception e) { 
            System.out.println(" Exception in retriever method in GIS!");
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    } /* end retriever*/
    
    
}
