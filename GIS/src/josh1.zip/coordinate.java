import java.util.ArrayList;

/**
 * 
 */

/**
 * @author A
 *
 */
public class coordinate implements Compare2D<coordinate>{

    private long xCoord;
    private long yCoord;
    private ArrayList<Long> prOffsets;
    
    public coordinate() {
        xCoord = 0;
        yCoord = 0;
        // initialize arraylist?
        /** the arraylist is unlimited, interesting? */
        prOffsets = new ArrayList<Long>();
    }
    
    public coordinate(long x, long y, long offset) {
        this.xCoord = x;
        this.yCoord = y;
        prOffsets = new ArrayList<Long>();
        prOffsets.add(offset);
    }
    
    public boolean equals(Object other) {
        if (other == null || (other.getClass() != this.getClass())) {
            return false;
        }
        coordinate o = (coordinate) other;
        return (o.getX() == this.getX() && o.getY() == this.getY());
    }
    @Override
    public long getX() {
        // TODO Auto-generated method stub
        return this.xCoord;
    }

    @Override
    public long getY() {
        // TODO Auto-generated method stub
        return this.yCoord;
    }
    
    public ArrayList<Long> offsets() {
        return this.prOffsets;
    }

    @Override
    public Direction directionFrom(double X, double Y) {

        if((X < xCoord && Y <= yCoord) || 
            (X == yCoord && Y == yCoord)){
        return Direction.NE;
    }
    else if(X >= xCoord && Y < yCoord){
        return Direction.NW;
    }
    else if(X > xCoord && Y >= yCoord ){
        return Direction.SW;
    }
    else{
       return Direction.SE; 
    }
        
    }

    @Override
    public Direction inQuadrant(
        double xLo,
        double xHi,
        double yLo,
        double yHi) {


        if (! this.inBox(xLo, xHi, yLo, yHi)) {
            //System.out.println(" I'm INQUADRANT in coordinate. I'm about to return NOQUADRANT AYYYYYYYYYYYYYYYYE");
            return Direction.NOQUADRANT;
        }
        
        return directionFrom( ((xLo + xHi) / 2.0), ((yLo + yHi)/2.0));
//        
//        if (xd > xNEW) {
//            /* it's eastern*/
//            if (yd >= yNEW) {
//                return Direction.NE;
//            }
//            else {
//                return Direction.SE;
//            }
//        }
//        else {
//            /* it's in the western. we do checks in the insert call itself so it's always withinj the world*/
//            /* x can still be on the median line. if northern quadrant it'lll be NW but southern it'll still be SE*/
//            if (yd == yNEW) {
//                return Direction.NE;
//            }
//            if (yd > yNEW) {
//                return Direction.NW;
//            } 
//            else { /* Yd is def less than ynew*/
//                // yd can still equal yd, whichi s sisu
//                return Direction.SW;
//            }
//        }
        
    }

    @Override
    public boolean inBox(double xLo, double xHi, double yLo, double yHi) {

        double xd = this.xCoord;
        double yd = this.yCoord;
       
//        System.out.println(" This might be the only problem!!! :" );
//        System.out.println(" xd is : " + xd);
//        System.out.println(" yd is : " + yd);
//        System.out.println("xlo, xhi, ylo, yhi : " + xLo + " " + xHi + " " + yLo + " " + yHi);
        if ((xd < xLo) || (xd > xHi) || (yd < yLo) || (yd > yHi)){
            //System.out.println( " xd < xlo");
            return false;
        }
        return true;
//        if (xd > xHi) {
//            //System.out.println("xd > xhi");
//            return false;
//        }
//        if (yd < yLo) {
//            //System.out.println("yd < ylo");
//            return false;
//        }
//        if (yd > yHi) { 
//            //System.out.println("yd >yHi");
//            return false;
//        }
//        
//        if(xd < xLo || xd > xHi || yd < yLo || yd > yHi) {
//            return false;
//        }
    }
    
    public String toString() {
        StringBuilder coor = new StringBuilder("[(" + this.xCoord + ", " + this.yCoord + "");
        for (int i = 0; i < this.offsets().size(); i++) {
            System.out.println(" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@************************%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            coor.append(", " + this.offsets().get(i));
        }
        coor.append("] ");
        return new String(coor);
    }
    
    
    

}
