/**
 * 
 */

/**
 * @author A
 *
 */

public enum Direction {NW, SW, SE, NE, NOQUADRANT};