/**
 * 
 */

/** The Direction enum for our project! Simply contains our directions
 * 
 * @author Josh Pandey
 * 
 *
 */

public enum Direction {NW, SW, SE, NE, NOQUADRANT};