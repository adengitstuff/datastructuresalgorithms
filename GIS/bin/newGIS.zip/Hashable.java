/**
 * 
 */

/**
 * @author A
 *
 */
public interface Hashable<T> {

    public int Hash();
}
