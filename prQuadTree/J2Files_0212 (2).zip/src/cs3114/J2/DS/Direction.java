package cs3114.J2.DS;

public enum Direction {NW, SW, SE, NE, NOQUADRANT};
