/**
 * 
 */

/**
 * @author A
 *
 */
public class RecordGIS {
    
    
    public RecordGIS() { 
        
        System.out.println("   ~~     Record  ~~~ ");
        
    }

}
